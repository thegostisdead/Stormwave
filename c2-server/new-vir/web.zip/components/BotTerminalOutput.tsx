import { TerminalOutput } from "react-terminal-ui";


export default function BotTerminalOutput(children : any) {
    return <TerminalOutput>{children}</TerminalOutput>
}