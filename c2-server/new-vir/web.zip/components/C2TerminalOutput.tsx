import { TerminalOutput } from "react-terminal-ui";


export default function C2TerminalOutput() {
    return <TerminalOutput>$C2: </TerminalOutput>
}



